import { useContext, useEffect, useRef, useState } from "react";
import { CiSearch } from "react-icons/ci";
import { CgProfile } from "react-icons/cg";
import { GoDotFill } from "react-icons/go";
import { UserContext } from "../context/userContext";
import axiosInstance from "../axios/interceptor";
import { socket } from "../../socket";
import Modal from "../helpers/Modal";
import { FaUserCircle } from "react-icons/fa";

const Sidebar = () => {
  const [search, setSearch] = useState("");
  const inputRef = useRef(null);
  const {
    loading,
    data,
    getUsers,
    setData,
    url,
    user,
    getSingleUser,
    setRoomData,
  } = useContext(UserContext);
  const email = localStorage.getItem("userEmail");
  const [notification, setNotification] = useState({});

  const [isModalOpen, setIsModalOpen] = useState(false);
  const openModal = () => setIsModalOpen(true);
  const closeModal = () => setIsModalOpen(false);

  const filterUsers = data.filter((user) =>
    user.name.toLowerCase().includes(search.toLowerCase())
  );

  const joinChat = async (receiverId) => {
    try {
      const response = await axiosInstance.post(`${url}/api/chat/join/chat`, {
        receiverId,
      });
      console.log(response.data);
      console.log(response.data.roomDetail.room + "room has been created");
      socket.emit("join_room", {
        roomId: response.data.roomDetail._id,
        userId: response.data.userDetail._id,
        receiver_id: response.data.receiverDetail._id,
      });
      setNotification((prev) => ({
        ...prev,
        [response.data.receiverDetail._id]: 0,
      }));
      socket.emit("clear-notification", {
        id: response.data.receiverDetail._id,
      });
      console.log(response.data);
      setRoomData(response.data);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    getSingleUser();

    socket.emit("online", email);
    socket.emit("join-user", email);
    socket.on("notification", (data) => {
      const { senderId, unread } = data;
      setNotification((prev) => ({
        ...prev,
        [senderId]: unread,
      }));
    });

    socket.on("user_online", (email) => {
      console.log("online", email);
      updateUserStatus(email, "online");
    });
    socket.on("offline", (email) => {
      console.log("offline", email);
      updateUserStatus(email, "offline");
    });
    getUsers();
    return () => {
      socket.off("user_online");
      socket.off("notification");
      socket.off("offline");
      socket.off("online");
    };
  }, []);

  const updateUserStatus = (email, status) => {
    setData((prevData) =>
      prevData.map((user) =>
        user.email === email ? { ...user, status } : user
      )
    );
  };

  const handleIconClick = () => {
    if (inputRef.current) {
      inputRef.current.focus(); // Focus on input when the icon is clicked
    }
  };
  return (
    <div className="p-4 mt-4  ">
      <div className="flex sticky top-10  justify-center     items-center  shadow-md  ">
        <FaUserCircle
          className="text-5xl mx-auto  cursor-pointer  text-green-500  mr-4 "
          onClick={openModal}
        />

        <div
          onClick={handleIconClick}
          className="bg-[#202c33]  rounded-l-md p-2 cursor-pointer"
        >
          <CiSearch className="text-2xl  text-gray-300" />
        </div>
        <input
          ref={inputRef}
          placeholder="Search..."
          className=" rounded-r-md border-none h-[40px] w-full   border-2 focus:outline-none text-lg bg-[#202c33]"
          type="text"
          name=""
          id=""
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>
      <Modal isOpen={isModalOpen} onClose={closeModal} title={user[0]?.name}>
        <p>{user[0]?.email}</p>
      </Modal>
      <div className=" px-16 py-4  ">
        {loading ? (
          <p>Loading...</p>
        ) : filterUsers.length === 0 ? (
          <p className="mx-auto  text-center  text-slate-500 font-medium text-lg">
            No users found...
          </p>
        ) : (
          filterUsers.map((item) => (
            <div
              key={item._id}
              className="flex  my-4 space-x-5  cursor-pointer hover:bg-[#2a3942] rounded-md p-4 items-center"
              onClick={() => joinChat(item.empId)}
            >
              <div className="w-[25%] ">
                <CgProfile className="text-5xl mx-auto text-green-500 " />
              </div>
              <ul className="  w-[75%]">
                <li className="text-lg font-semibold">{item.name}</li>

                <div className="flex items-center ">
                  <span className="">
                    <GoDotFill
                      className={
                        item.status === "online"
                          ? "text-green-500"
                          : "text-red-500"
                      }
                    />
                  </span>
                  <p className="text-sm text-gray-500">{item.status}</p>
                </div>
              </ul>
              {console.log(notification, "unreadMessages")}
              {notification[item._id] > 0 && (
                <p className="bg-green-500 text-slate-200 px-2 rounded-full">
                  {notification[item._id]}
                </p>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default Sidebar;
